# SchichtZeit V5 Android Test Edition

## APK automatisch bauen
1. Projekt auf GitHub hochladen.
2. Repository öffnen → Actions.
3. Workflow „Build SchichtZeit Android Test APK“ auswählen.
4. „Run workflow“ drücken.
5. Nach Abschluss Artifact „SchichtZeit-V5-Test-APK“ herunterladen.
6. ZIP entpacken und app-debug.apk auf dem Android-Handy öffnen.

GitHub Actions baut die APK automatisch mit Node, Java, Capacitor und Gradle.
Die Test-APK ist nicht für den Play Store bestimmt.
