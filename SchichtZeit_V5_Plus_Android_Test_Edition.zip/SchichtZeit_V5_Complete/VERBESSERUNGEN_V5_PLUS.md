# V5 Plus – zusätzliche Verbesserungen

- Professionelles mobiles Dashboard
- Navigationsbereiche Heute, Kalender, Import, Statistik, Einstellungen
- Schnellwahl für alle Schichtarten
- Notizen pro Schicht
- Mobile Kamera-Auswahl für Schichtpläne
- OCR-Bereich mit Kontrollmöglichkeit
- Statistik-Kacheln
- Offline-first Speicherung
- Vorbereitete Einstellungen für Erinnerungen, Cloud und Kalender
- Verbesserte Android-Test-Build-Pipeline

## Nächste Ausbaustufe
Für eine echte APK muss der GitHub-Workflow einmal erfolgreich laufen. Das Ergebnis ist anschließend `app-debug.apk`.
