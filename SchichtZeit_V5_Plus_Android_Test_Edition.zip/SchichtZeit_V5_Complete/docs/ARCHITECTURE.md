# Architektur
React/Capacitor Client -> HTTPS/JWT -> Express API -> PostgreSQL

Offline:
1. Änderungen werden zuerst IndexedDB gespeichert.
2. Mutationen landen in einer Queue.
3. Bei Online-Verbindung wird synchronisiert.
4. Server ist führende Instanz; Konflikte werden über updatedAt/version gelöst.

OCR:
Clientseitiges Tesseract als Offline-Basis. Für komplexe Tabellen ist ein optionaler serverseitiger Vision-Provider vorgesehen. Unsichere Ergebnisse müssen vor Import bestätigt werden.
