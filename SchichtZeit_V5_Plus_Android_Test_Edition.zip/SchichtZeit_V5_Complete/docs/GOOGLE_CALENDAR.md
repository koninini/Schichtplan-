# Google Calendar
Separate OAuth Clients für Web und Android verwenden. Nur minimale Scopes anfordern. OAuth-Code serverseitig gegen Tokens tauschen. Refresh Tokens verschlüsselt speichern. Google Event IDs pro Schichteintrag speichern, um Duplikate zu vermeiden.
