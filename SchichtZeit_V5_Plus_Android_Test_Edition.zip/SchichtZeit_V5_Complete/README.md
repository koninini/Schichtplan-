# SchichtZeit V5 Complete
Komplette Monorepo-Grundstruktur für produktive Weiterentwicklung.

## Bestandteile
- React/Vite Web-App
- Capacitor Android-Struktur
- Express/TypeScript Backend
- PostgreSQL Datenmodell
- JWT Auth-Grundlage
- Offline-first IndexedDB
- Cloud-Sync Queue
- OCR-Schichtplanimport
- Google Calendar Integrationsarchitektur
- Docker PostgreSQL

## Start
1. .env.example nach .env kopieren
2. docker compose up -d
3. npm install
4. npm run dev:api
5. npm run dev:web

## Android
cd apps/web
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android

Android Studio erstellt daraus Debug-APK oder signiertes AAB/APK.
